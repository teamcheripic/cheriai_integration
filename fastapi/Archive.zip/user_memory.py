"""
CheriAI long-term user memory.

What lives here (one row per user in cheri_ai_user_memory):
- summary   : 1–2 sentence portrait of the person Cheri is talking to
- insights  : small array of concrete facts she's learned
              (each: {"fact": "...", "ts": "ISO date"})

The chat endpoint:
1. Loads memory + last few messages BEFORE building the prompt
   → Cheri replies with full context
2. Fires update_memory_async AFTER the reply is sent
   → cheap second LLM call, non-blocking, only when the turn was substantive
"""

import json
import logging
from datetime import datetime
from typing import Any

from llm_client import send_to_llm
from supabase_client import supabase

logger = logging.getLogger(__name__)

MAX_INSIGHTS = 12          # keep memory small + cheap
RECENT_TURNS = 6           # last 6 messages in short-term context
MIN_MSG_CHARS = 25         # skip distillation for "ok" / "thanks" / etc.
DISTILL_MAX_TOKENS = 220   # ~2x typical reply — enough for JSON output


# --------------------------------------------------------------- READ helpers

async def load_memory(user_id: str) -> dict[str, Any]:
    """Returns {"summary": str, "insights": list, "turn_count": int}."""
    try:
        rows = await supabase.select(
            "cheri_ai_user_memory",
            columns="summary,insights,turn_count",
            eq={"user_id": user_id},
            limit=1,
        )
        if rows:
            row = rows[0]
            return {
                "summary": row.get("summary") or "",
                "insights": row.get("insights") or [],
                "turn_count": row.get("turn_count") or 0,
            }
    except Exception as e:
        logger.warning(f"[memory] load failed: {e}")
    return {"summary": "", "insights": [], "turn_count": 0}


async def load_recent_messages(user_id: str, limit: int = RECENT_TURNS) -> list[dict]:
    """Last N messages across all conversations, oldest-first."""
    try:
        rows = await supabase.select(
            "chat_history",
            columns="role,content,created_at",
            eq={"user_id": user_id},
            order="created_at.desc",
            limit=limit,
        )
        return list(reversed(rows))
    except Exception as e:
        logger.warning(f"[memory] history load failed: {e}")
        return []


# --------------------------------------------------------------- WRITE / distill

_DISTILL_SYSTEM = (
    "You maintain a private notebook on a user so a friend (Cheri) can talk to "
    "them with continuity. Output STRICT JSON only, no prose:\n"
    '{ "summary": "1–2 sentence portrait, updated", "new_insights": ["fact 1", "fact 2"] }\n'
    "Rules:\n"
    "- summary: revise the existing one if you learned something new; otherwise return it unchanged.\n"
    "- new_insights: 0–3 short concrete facts ONLY if they're durable (values, situation, preferences). "
    "  Skip small talk, greetings, and anything Cheri already knows.\n"
    "- Never include opinions, advice, or interpretations — only what the user revealed.\n"
    "- Keep each insight under 110 characters."
)


def _build_distill_prompt(
    existing_summary: str,
    existing_insights: list[dict],
    user_message: str,
    assistant_reply: str,
) -> str:
    known = "\n".join(f"- {i.get('fact', '')}" for i in existing_insights[-MAX_INSIGHTS:])
    return (
        f"Existing summary: {existing_summary or '(none yet)'}\n"
        f"Existing insights:\n{known or '(none yet)'}\n\n"
        f"Latest user message: {user_message}\n"
        f"Cheri's reply: {assistant_reply}\n\n"
        "Return updated JSON."
    )


def _merge_insights(existing: list[dict], new_facts: list[str]) -> list[dict]:
    """Append unique new facts; cap at MAX_INSIGHTS keeping the most recent."""
    seen = {(i.get("fact") or "").strip().lower() for i in existing}
    now = datetime.now().isoformat()
    out = list(existing)
    for fact in new_facts:
        f = (fact or "").strip()
        if f and f.lower() not in seen:
            out.append({"fact": f, "ts": now})
            seen.add(f.lower())
    return out[-MAX_INSIGHTS:]


async def update_memory_async(
    user_id: str,
    user_message: str,
    assistant_reply: str,
) -> None:
    """
    Fire-and-forget: distill what Cheri learned from this turn and merge into
    the user's memory row. Skips quietly on short messages or any error.
    """
    if len(user_message.strip()) < MIN_MSG_CHARS:
        return

    try:
        current = await load_memory(user_id)
        prompt = _build_distill_prompt(
            current["summary"], current["insights"], user_message, assistant_reply
        )
        raw = await send_to_llm(
            (_DISTILL_SYSTEM, prompt),
            max_tokens=DISTILL_MAX_TOKENS,
            user=user_id,
        )

        # Be lenient about model formatting
        text = raw.strip()
        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end == -1:
            logger.info("[memory] distill returned no JSON; skipping")
            return
        parsed = json.loads(text[start : end + 1])

        new_summary = (parsed.get("summary") or current["summary"] or "").strip()
        new_facts = parsed.get("new_insights") or []
        if not isinstance(new_facts, list):
            new_facts = []

        merged = _merge_insights(current["insights"], [str(f) for f in new_facts])

        await supabase.upsert(
            "cheri_ai_user_memory",
            {
                "user_id": user_id,
                "summary": new_summary,
                "insights": merged,
                "turn_count": (current["turn_count"] or 0) + 1,
                "updated_at": datetime.now().isoformat(),
            },
            on_conflict="user_id",
        )
        logger.info(f"[memory] updated for {user_id} (+{len(new_facts)} insights)")
    except Exception as e:
        # never break the chat path
        logger.warning(f"[memory] update failed: {e}")
